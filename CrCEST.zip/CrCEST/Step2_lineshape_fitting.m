% simulate z spectrum
% blochFittingCurve to simulate 
%% 
addpath('toolbox_SL');
clear all;
load 2uT

satpar.pwr=2;
satpar.legnth=1;
%water T1
load BGpara;
%exchnage rate
x0 =[300,0.08,30]; % x(1):exchange rate, concentration, T2
lb = [0,20,30];
ub = [500,20,30];

   Freq=zspect(:,1);
   dZ=zspect(:,4);
      options=optimset('MaxFunEvals',1000000,'TolFun',1e-10,'TolX',1e-10, 'Display',  'off' );
    [x,~] = lsqcurvefit(@blochFittingCurve,x0,Freq,dZ,lb,ub,options,BGpara,satpar);

  [ DCr z_simulation zback ]= blochFittingCurve(x,Freq,BGpara,satpar);
 R2values=rsquare(dZ,DCr)
 
 Freqout=0:0.02:8;
Freqout=Freqout';
  [ DCr z_simulation zback ]= blochFittingCurve(x,Freqout,BGpara,satpar);
%%

% draw curve LZCF93N4LMRSLHDY


colorOrder = ...
[
   1 0.50 0.25 % 11 ORANGE
   0 0.75 0.75 % 8 TURQUOISE
   0 0.5 0 % 9 GREEN (dark)
   0.75 0.75 0 % 10 YELLOW (dark)
   0.75 0 0.75 % 12 MAGENTA (dark)
   0.8 0.7 0.6 % 14 BROWN (pale)
   0.6 0.5 0.4 ]; % 15 BROWN (dark)
      
figure1=figure(1);

axes1 = axes(...
  'FontSize',20,...
  'Position',[0.12 0.15 0.8 0.8],'LineWidth',2,...
  'Parent',figure1);
xlabel(axes1,'Saturation Offset (ppm)');
ylabel(axes1,'DZ  ');
box(axes1,'on');
hold(axes1,'all');
%axis(axes1,[-8 8 0 105 ]);

   plot(zspect(:,1),zspect(:,4),'x','Color',colorOrder(2,:),'LineWidth',3,'MarkerSize',10,'Parent',axes1);
 
hold on;
    plot(Freqout,DCr,'-','Color',colorOrder(1,:),'LineWidth',3,'MarkerSize',10,'Parent',axes1);
 set(gca, 'XDir','reverse')

