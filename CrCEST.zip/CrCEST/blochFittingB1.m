function [dZ z_simulation zback ]= blochFittingB1(x,B1list,BGpara,satpar)
Freq=1.95;
for idx=1:max(size(B1list))
    satpar.pwr=B1list(idx);
dZ(idx,1)=blochFittingCurve(x,Freq,BGpara,satpar);

end  
end

