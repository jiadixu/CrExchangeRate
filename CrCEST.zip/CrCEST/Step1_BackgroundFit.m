% simulate z spectrum
% blochFittingCurve to simulate 
%% 
addpath('toolbox_SL');
clear all;
load 2uT

satpar.pwr=2;
satpar.legnth=1;

%exchnage rate
x0 =[1.8,0.038,0.02,0.05,-3.5]; % x(1):MTC T2 ; x(2):T2 concentration
lb = [1.8,0.038,0,0,-3.5];
ub = [1.8,0.038,0.05,0.2,-3.5];

 %rician noise correction
 %zspect(:,3)=(zspect(:,3)-zspect(end,3))./(1-zspect(end,3));
 
 Freq=[zspect(1:7,1); zspect(52:end,1)];
   Zbak=[zspect(1:7,3); zspect(52:end,3)];
      options=optimset('MaxFunEvals',1000000,'TolFun',1e-10,'TolX',1e-10, 'Display',  'off' );
    [x,~] = lsqcurvefit(@blochFittingBG,x0,Freq,Zbak,lb,ub,options,satpar);

 BGpara=x;
 
 
  [ zback ]= blochFittingBG(x,Freq,satpar);
 R2values=rsquare(Zbak,zback)
 
save BGpara BGpara;
Freqout=0:0.02:8;
Freqout=Freqout';

   MTC= blochFittingBG(x,Freqout,satpar);
%%

% draw curve


colorOrder = ...
[
   1 0.50 0.25 % 11 ORANGE
   0 0.75 0.75 % 8 TURQUOISE
   0 0.5 0 % 9 GREEN (dark)
   0.75 0.75 0 % 10 YELLOW (dark)
   0.75 0 0.75 % 12 MAGENTA (dark)
   0.8 0.7 0.6 % 14 BROWN (pale)
   0.6 0.5 0.4 ]; % 15 BROWN (dark)
      
figure1=figure(1);

axes1 = axes(...
  'FontSize',20,...
  'Position',[0.12 0.15 0.8 0.8],'LineWidth',2,...
  'Parent',figure1);
xlabel(axes1,'Saturation Offset (ppm)');
ylabel(axes1,'DZ  ');
box(axes1,'on');
hold(axes1,'all');
%axis(axes1,[-8 8 0 105 ]);

   plot(Freq,Zbak,'x','Color',colorOrder(2,:),'LineWidth',3,'MarkerSize',10,'Parent',axes1);
 
hold on;
    plot(Freqout,MTC,'-','Color',colorOrder(1,:),'LineWidth',3,'MarkerSize',10,'Parent',axes1);
 set(gca, 'XDir','reverse')

